const express = require('express');
const Tweet = require('../models/Tweet');
const router = express.Router();

router.get('/', (req, res) => {
  res.render('index');
});

// POST route for the initial search
router.post('/search', async (req, res) => {
    const { minLikes, minRetweets, sentiment } = req.body;
    const currentPage = parseInt(req.query.page) || 1; // Default to the first page
    const tweetsPerPage = 15; // Display 15 tweets per page

    const queryMinLikes = minLikes ? parseInt(minLikes) : 0;
    const queryMinRetweets = minRetweets ? parseInt(minRetweets) : 0;

    // Build query for tweets
    let query = {
        likes: { $gte: queryMinLikes },
        retweetCount: { $gte: queryMinRetweets }
    };

    if (sentiment !== 'both') {
        query.sentiment = sentiment; // Filter for specific sentiment
    }

    try {
        // Paginated tweet results
        const tweets = await Tweet.find(query)
            .skip((currentPage - 1) * tweetsPerPage)
            .limit(tweetsPerPage);

        // Count positive and negative tweets for the whole dataset
        const sentimentCounts = {
            positive: await Tweet.countDocuments({ ...query, sentiment: 'positive' }),
            negative: await Tweet.countDocuments({ ...query, sentiment: 'negative' })
        };

        // Calculate total pages for pagination
        const totalTweets = await Tweet.countDocuments(query);
        const totalPages = Math.ceil(totalTweets / tweetsPerPage);

        // Render the results.ejs file with data
        res.render('results', {
            tweets,
            currentPage,
            totalPages,
            minLikes: queryMinLikes,
            minRetweets: queryMinRetweets,
            sentiment,
            sentimentCounts
        });
    } catch (err) {
        console.error('Error retrieving tweets:', err);
        res.status(500).send('Error retrieving tweets');
    }
});

// GET route for pagination
router.get('/search', async (req, res) => {
    const { page, minLikes, minRetweets, sentiment, sortBy } = req.query;
    const currentPage = parseInt(page) || 1;
    const tweetsPerPage = 15;

    const queryMinLikes = minLikes ? parseInt(minLikes) : 0;
    const queryMinRetweets = minRetweets ? parseInt(minRetweets) : 0;

    let query = {
        likes: { $gte: queryMinLikes },
        retweetCount: { $gte: queryMinRetweets },
    };

    if (sentiment !== 'both') {
        query.sentiment = sentiment;
    }

    let sortCriteria = {};
    if (sortBy === 'likes') {
        sortCriteria = { likes: -1 };
    } else if (sortBy === 'retweets') {
        sortCriteria = { retweetCount: -1 };
    } else if (sortBy === 'sentiment') {
        sortCriteria = { sentiment: 1 }; // Assuming 'negative' should come before 'positive'
    }

    try {
        const tweets = await Tweet.find(query)
            .sort(sortCriteria)
            .skip((currentPage - 1) * tweetsPerPage)
            .limit(tweetsPerPage);

        const sentimentCounts = {
            positive: await Tweet.countDocuments({ ...query, sentiment: 'positive' }),
            negative: await Tweet.countDocuments({ ...query, sentiment: 'negative' })
        };

        const totalTweets = await Tweet.countDocuments(query);
        const totalPages = Math.ceil(totalTweets / tweetsPerPage);

        res.render('results', {
            tweets,
            currentPage,
            totalPages,
            minLikes: queryMinLikes,
            minRetweets: queryMinRetweets,
            sentiment,
            sortBy,
            sentimentCounts
        });
    } catch (err) {
        console.error('Error retrieving tweets:', err);
        res.status(500).send('Error retrieving tweets');
    }
});

module.exports = router;
